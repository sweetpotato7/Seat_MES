﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace MESProject.기준정보
{
    public partial class CODE_MST : Form
    {
        SQL sql = new SQL();

        public CODE_MST()
        {
            InitializeComponent();
        }

        public void Search()
        {
            
        }

        public void disp() // MajorCode
        {
            SqlCommand cmd = sql.conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TB_CODE_MST";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        
        public void disp2() // SubCode
        {
            SqlCommand cmd = sql.conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TB_CODE_MST";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void CODE_MST_Load(object sender, EventArgs e)
        {
            if (sql.conn.State == ConnectionState.Open)
            {
                sql.conn.Close();
            }
            sql.conn.Open();
            disp();
            disp2();
        }
    }
}
